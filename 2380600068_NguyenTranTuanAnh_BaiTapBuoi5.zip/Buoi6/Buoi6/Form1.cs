﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Data.Entity; // [CS0246] Cần thiết cho phương thức .Include()
using Buoi6.Models;     // [CS0234/CS0246] Đã sửa: Phải trỏ đến namespace chứa các lớp Model

namespace Buoi6
{
    public partial class Form1 : Form
    {
        // Biến toàn cục để lưu danh sách Khoa
        private List<Faculty> _listFaculty;

        public Form1()
        {
            InitializeComponent();
        }

        #region HÀM HỖ TRỢ (ĐÃ BỔ SUNG ĐỂ KHẮC PHỤC LỖI CS0103)

        private void BindGrid(List<Student> listStudent)
        {
            dgvStudent.Rows.Clear();

            foreach (Student item in listStudent)
            {
                int index = dgvStudent.Rows.Add();
                dgvStudent.Rows[index].Cells["StudentID"].Value = item.StudentID;
                dgvStudent.Rows[index].Cells["FullName"].Value = item.FullName;

                if (item.Faculty != null)
                {
                    dgvStudent.Rows[index].Cells["FacultyName"].Value = item.Faculty.FacultyName;
                }
                else
                {
                    dgvStudent.Rows[index].Cells["FacultyName"].Value = "N/A";
                }

                dgvStudent.Rows[index].Cells["AverageScore"].Value = item.AverageScore;
            }
        }

        private void ResetInputFields()
        {
            // ĐÃ SỬA: Dùng Clear() cho TextBox (Khắc phục lỗi CS1061)
            txtStudentID.Clear();
            txtName.Clear();
            txtAverageScore.Clear();
            cboFaculty.SelectedIndex = -1;
            txtStudentID.Focus();
        }

        private void RefreshDataAndResetForm()
        {
            ResetInputFields();

            try
            {
                Model1 context = new Model1();

                // Khắc phục lỗi CS0246 khi gọi StudentContextDB/Student
                List<Student> listStudent = context.Students.Include("Faculty").ToList();
                BindGrid(listStudent);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải lại dữ liệu: " + ex.Message, "Lỗi");
            }
        }

        #endregion

        #region SỰ KIỆN FORM VÀ DATAGRIDVIEW

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                Model1 context = new Model1();

                // 1. Lấy danh sách Faculty (Khoa) và gán vào ComboBox Khoa
                _listFaculty = context.Faculties.ToList();
                cboFaculty.DataSource = _listFaculty;
                cboFaculty.DisplayMember = "FacultyName";
                cboFaculty.ValueMember = "FacultyID";
                cboFaculty.SelectedIndex = -1;

                // 2. Lấy danh sách Student và hiển thị lên DataGridView
                List<Student> listStudent = context.Students.Include("Faculty").ToList();
                BindGrid(listStudent);

                ResetInputFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void Form1_Click(object sender, EventArgs e) { }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvStudent.RowCount - 1)
            {
                DataGridViewRow row = dgvStudent.Rows[e.RowIndex];

                string studentID = row.Cells["StudentID"].Value.ToString();
                string fullName = row.Cells["FullName"].Value.ToString();
                string facultyName = row.Cells["FacultyName"].Value.ToString();
                string averageScore = row.Cells["AverageScore"].Value.ToString();

                // Dùng txtStudentID (TextBox)
                txtStudentID.Text = studentID;
                txtName.Text = fullName;
                txtAverageScore.Text = averageScore;

                // Set ComboBox Khoa
                if (_listFaculty != null)
                {
                    Faculty selectedFaculty = _listFaculty.FirstOrDefault(f => f.FacultyName == facultyName);
                    if (selectedFaculty != null)
                    {
                        cboFaculty.SelectedValue = selectedFaculty.FacultyID;
                    }
                }
            }
        }

        #endregion

        #region SỰ KIỆN THÊM, SỬA, XÓA

        private void btnThem_Click(object sender, EventArgs e)
        {
            string studentID = txtStudentID.Text.Trim();

            if (string.IsNullOrWhiteSpace(studentID) || studentID.Length != 10)
            {
                MessageBox.Show("Vui lòng nhập MSSV (10 kí tự) và đầy đủ thông tin!", "Cảnh báo");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtAverageScore.Text) || cboFaculty.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Cảnh báo");
                return;
            }

            try
            {
                Model1 context = new Model1();

                Student dbCheck = context.Students.FirstOrDefault(p => p.StudentID == studentID);
                if (dbCheck != null)
                {
                    MessageBox.Show("Sinh viên đã tồn tại, không thể thêm!", "Lỗi");
                    return;
                }

                double score;
                if (!double.TryParse(txtAverageScore.Text, out score))
                {
                    MessageBox.Show("Điểm TB không hợp lệ!", "Lỗi");
                    return;
                }

                Student newStudent = new Student()
                {
                    StudentID = studentID,
                    FullName = txtName.Text.Trim(),
                    FacultyID = (int)cboFaculty.SelectedValue,
                    AverageScore = score
                };

                context.Students.Add(newStudent);
                context.SaveChanges();

                MessageBox.Show("Thêm sinh viên thành công!", "Thông báo");
                RefreshDataAndResetForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message, "Lỗi");
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string studentID = txtStudentID.Text.Trim();

            if (string.IsNullOrWhiteSpace(studentID))
            {
                MessageBox.Show("Vui lòng nhập Mã số sinh viên cần cập nhật.", "Cảnh báo");
                return;
            }

            try
            {
                Model1 context = new Model1();

                Student dbUpdate = context.Students.FirstOrDefault(p => p.StudentID == studentID);

                if (dbUpdate == null)
                {
                    MessageBox.Show("Không tìm thấy sinh viên cần sửa!", "Lỗi");
                    return;
                }

                double score;
                if (!double.TryParse(txtAverageScore.Text, out score))
                {
                    MessageBox.Show("Điểm TB không hợp lệ!", "Lỗi");
                    return;
                }

                dbUpdate.FullName = txtName.Text.Trim();
                dbUpdate.FacultyID = (int)cboFaculty.SelectedValue;
                dbUpdate.AverageScore = score;

                context.SaveChanges();

                MessageBox.Show("Cập nhật sinh viên thành công!", "Thông báo");
                RefreshDataAndResetForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật: " + ex.Message, "Lỗi");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string studentID = txtStudentID.Text.Trim();

            if (string.IsNullOrWhiteSpace(studentID))
            {
                MessageBox.Show("Vui lòng nhập Mã số sinh viên cần xóa.", "Cảnh báo");
                return;
            }

            try
            {
                Model1 context = new Model1();

                Student dbDelete = context.Students.FirstOrDefault(p => p.StudentID == studentID);

                if (dbDelete == null)
                {
                    MessageBox.Show("Không tìm thấy sinh viên cần xóa!", "Lỗi");
                    return;
                }

                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa sinh viên {dbDelete.FullName}?",
                    "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    context.Students.Remove(dbDelete);
                    context.SaveChanges();

                    MessageBox.Show("Xóa sinh viên thành công!", "Thông báo");
                    RefreshDataAndResetForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message, "Lỗi");
            }
        }
    }
}
#endregion  